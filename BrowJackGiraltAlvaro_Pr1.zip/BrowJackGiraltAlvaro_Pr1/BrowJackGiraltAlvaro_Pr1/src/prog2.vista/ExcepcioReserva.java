//Se lanza cuando una reserva no cumple las condiciones requeridas.
package prog2.vista;
/**
 *
 * @author lauraigual
 */
public class ExcepcioReserva extends Exception {

    public ExcepcioReserva(String message) {
        super(message);
    }
}