//Funciona correctamente si tiene casa para mascota.
package prog2.model;

public class Glamping extends Casa{
    private boolean casaMascota;
    protected String material;

    public Glamping(String nom, String id, int estadaMinimaBaixa, int estadaMaximaAlta, int numHabitacions, int capacitat,String material, boolean casaMascota) {
        super(nom, id, estadaMinimaBaixa, estadaMaximaAlta, numHabitacions, capacitat);
        this.casaMascota = casaMascota;
        this.material = material;
    }
    //Getter
    public boolean getCasaMascota() {
        return casaMascota;
    }
    //Setter
    public void setCasaMascota(boolean casaMascota) {
        this.casaMascota = casaMascota;
    }
    //Funcionament correcte d'un Glamping depén de si té casa per mascotes o no.
    @Override
    public boolean correcteFuncionament() {
        return casaMascota;
    }
    //Afegim informació característica de Glamping al métode toString.
    @Override
    public String toString() {
        return super.toString() + " Glamping{material=" + material + ", casaMascota=" + casaMascota + "}";
    }
}
