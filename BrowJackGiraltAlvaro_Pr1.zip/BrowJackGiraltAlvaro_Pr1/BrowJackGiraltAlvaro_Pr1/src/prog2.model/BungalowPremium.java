//Funciona correctamente si tiene aire frío y el código WiFi tiene 8-16 caracteres.
package prog2.model;

public class BungalowPremium extends Bungalow{
    private boolean llencolsTovalloles;
    private String codiWifi;

    public BungalowPremium(String nom, String id, int estadaMinBaixa, int estadaMinAlta, int numHabitacions, int capacitat, int numPlacesAparcament, boolean terrassa, boolean televisio, boolean aireFred, boolean llencolsTovalloles,String codiWifi) {
        super(nom,id,estadaMinBaixa,estadaMinAlta,numHabitacions,capacitat,numPlacesAparcament,terrassa,televisio,aireFred);
        this.llencolsTovalloles = llencolsTovalloles;
        this.codiWifi = codiWifi;
    }
    //Getters
    public boolean getLlencolsTovalloles() {
        return llencolsTovalloles;
    }
    public String getCodiWifi () {
        return codiWifi;
    }
    //Setters
    public void setLlencolsTovalloles (boolean llencolsTovalloles) {
        this.llencolsTovalloles = llencolsTovalloles;
    }
    public void setCodiWifi (String codiWifi) {
        this.codiWifi = codiWifi;
    }
    //Funcionament correcte de bungalow premium depen de si té codi wifi (entre 8 i 16 caràcters) i de si té aire fred.
    @Override
    public boolean correcteFuncionament() {
        return (codiWifi != null && codiWifi.length() >= 8 && codiWifi.length() <= 16) && aireFred;
    }
    //Afegir informació característica de Bungalow premium al mètode toString.
    @Override
    public String toString() {
        return super.toString() + " BungalowPremium{llençolsTovalloles=" + llencolsTovalloles +
                ", codiWifi='" + codiWifi + "'}";
    }
}
