//Clase base para alojamientos
package prog2.model;

public abstract class Allotjament implements InAllotjament {
    protected String nom;
    protected String id;
    protected int estadaMinBaixa;
    protected int estadaMinAlta;

    public Allotjament(String nom, String id, int estadaMinBaixa, int estadaMinAlta) {
        this.nom = nom;
        this.id = id;
        this.estadaMinBaixa = estadaMinBaixa;
        this.estadaMinAlta = estadaMinAlta;
    }
    //Getters
    public String getNom() {
        return nom;
    }

    public String getId() {
        return id;
    }

    public int getEstadaMinimaBaixa() {
        return estadaMinBaixa;
    }

    public int getEstadaMinimaAlta() {
        return estadaMinAlta;
    }
    //Setters
    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setEstadaMinimaBaixa(int estadaMinBaixa) {
        this.estadaMinBaixa = estadaMinBaixa;
    }

    public void setEstadaMinimaAlta(int estadaMinAlta) {
        this.estadaMinAlta = estadaMinAlta;
    }
    @Override
    public String toString() {
        return "Nom= " + nom + ", Id: " + id + ", estada mínima en temp ALTA: " + estadaMinAlta + ", estada mínima en temp BAIXA: " + estadaMinBaixa + ". " + getClass().getSimpleName();
    }

    public abstract boolean correcteFuncionament(); //Define si el alojamiento es operativo
}
