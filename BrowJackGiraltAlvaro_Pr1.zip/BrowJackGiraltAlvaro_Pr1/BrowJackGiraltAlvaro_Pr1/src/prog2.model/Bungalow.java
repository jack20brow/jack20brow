//Funciona correctamente si tiene aire frío
package prog2.model;

public class Bungalow extends Casa {
    private int numPlacesAparcament;
    private boolean terrassa;
    private boolean televisio;
    protected boolean aireFred;

    //Constructor
    public Bungalow (String nom, String id, int estadaMinBaixa, int estadaMinAlta, int numHabitacions, int capacitat, int numPlacesAparcament, boolean terrassa, boolean televisio, boolean aireFred) {
        super(nom, id, estadaMinBaixa, estadaMinAlta, numHabitacions, capacitat); //Falta crear constructor casa
        this.numPlacesAparcament = numPlacesAparcament;
        this.terrassa = terrassa;
        this.televisio = televisio;
        this.aireFred = aireFred;
    }

    @Override
    public String getNom() {
        return "";
    }

    @Override
    public void setNom(String nom) {

    }

    @Override
    public String getId() {
        return "";
    }

    @Override
    public void setId(String id) {

    }

    @Override
    public long getEstadaMinima(Temp temp) {
        return 0;
    }

    @Override
    public void setEstadaMinima(long estadaMinimaALTA_, long estadaMinimaBAIXA_) {

    }

    public boolean correcteFuncionament() {
        return aireFred; //Només funciona correctament si te aire fred habilitat.
    };

    public int getHabitacions() {
        return numHabitacions;
    }
}
