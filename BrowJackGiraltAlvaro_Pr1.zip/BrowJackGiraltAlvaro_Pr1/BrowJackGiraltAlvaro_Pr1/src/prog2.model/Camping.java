//Clase que gestiona toda la información del camping
package prog2.model;
import java.util.ArrayList;
import java.time.LocalDate;

public class Camping implements InCamping {
    private String nom;
    private ArrayList<Allotjament> allotjaments;
    private ArrayList<Client> clients;
    private ArrayList<Reserva> llistaReserves;

    public Camping(String nom){
        this.nom = nom;
        this.allotjaments = new ArrayList<>();
        this.clients = new ArrayList<>();
        this.llistaReserves = new ArrayList<>();
    }
    public void afegirReserva(Allotjament allotjament, Client client, LocalDate dataEntrada, LocalDate dataSortida) {
        System.out.println("Reserva afegida: Cliente " + client + ", Allotjament " + allotjament +
                ", des de " + dataEntrada + " fins " + dataSortida);
    }
    public void afegirParcela(String nom, String id, int estadaMinimaBaixa, int estadaMaximaAlta,float mida, boolean connexioElectrica){
        Parcela novaParcela = new Parcela(nom,id,estadaMinimaBaixa,estadaMaximaAlta,mida,connexioElectrica);
        allotjaments.add(novaParcela);
    }
    public void afegirBungalow(String nom, String id, int estadaMinBaixa, int estadaMinAlta, int numHabitacions, int capacitat, int numPlacesAparcament, boolean terrassa, boolean televisio, boolean aireFred){
        Bungalow nouBungalow = new Bungalow(nom,id,estadaMinBaixa,estadaMinAlta,numHabitacions,capacitat,numPlacesAparcament,terrassa,televisio,aireFred);
        allotjaments.add(nouBungalow);
    }
    public void afegirBungalowPremium(String nom, String id, int estadaMinBaixa, int estadaMinAlta, int numHabitacions, int capacitat, int numPlacesAparcament, boolean terrassa, boolean televisio, boolean aireFred, boolean llençolsTovalloles,String codiWifi){
        BungalowPremium nouBungalowPremium = new BungalowPremium(nom,id,estadaMinBaixa,estadaMinAlta,numHabitacions,capacitat,numPlacesAparcament,terrassa,televisio,aireFred,llençolsTovalloles,codiWifi);
        allotjaments.add(nouBungalowPremium);
    }
    public void afegirGlamping(String nom, String id, int estadaMinimaBaixa, int estadaMaximaAlta, int numHabitacions, int capacitat,String material, boolean casaMascota){
        Glamping nouGlamping = new Glamping(nom,id,estadaMinimaBaixa,estadaMaximaAlta,numHabitacions,capacitat,material,casaMascota);
        allotjaments.add(nouGlamping);
    }
    public void afegirMobilHome(String nom, String id, int estadaMinBaixa, int estadaMinAlta, int numHabitacions, int capacitat, boolean terrassaBarbacoa){
        MobilHome nouMobilHome = new MobilHome(nom,id,estadaMinBaixa,estadaMinAlta,numHabitacions,capacitat,terrassaBarbacoa);
        allotjaments.add(nouMobilHome);
    }
    @Override
    public void afegirClient(String nomClient, String dni) {
        System.out.println("Afegim client: " + nom + " DNI: " + dni);
    }

    //Getters
    @Override
    public String getNom() {
        return this.nom;
    }

    @Override
    public ArrayList<Reserva> getLlistaReserves() {
        return this.llistaReserves;
    }

    @Override
    public ArrayList<Allotjament> getLlistaAllotjaments() {
        return this.allotjaments;
    }

    @Override
    public ArrayList<Client> getLlistaClients() {
        return this.clients;
    }

    @Override
    public int getNumAllotjaments() {
        return this.allotjaments.size();
    }

    @Override
    public int getNumReserves() {
        return this.llistaReserves.size();
    }

    @Override
    public int getNumClients() {
        return this.clients.size();
    }

    @Override
    public float calculMidaTotalParceles() {
    float midaTotal = 0;
    for (Allotjament allotjament : allotjaments) {
        if (allotjament instanceof Parcela) { // Verifiquem si és una parcel·la
            Parcela parcela = (Parcela) allotjament;
            midaTotal += parcela.getMida(); // Suposant que Parcela té un getter getMida()
        }
    }
    return midaTotal;
}

    @Override
    public int calculAllotjamentsOperatius() {
    int count = 0;
    for (Allotjament allotjament : allotjaments) {
        if (allotjament.correcteFuncionament()) { // Allotjament té un mètode correcteFuncionament()
            count++;
        }
    }
    return count;
}

    @Override
    public Allotjament getAllotjamentEstadaMesCurta() {
    if (allotjaments.isEmpty()) {
        return null;
    }

    Allotjament estadaMesCurta = allotjaments.get(0);
    int minEstada = estadaMesCurta.getEstadaMinimaBaixa(); // Suposant que Allotjament té aquest getter

    for (Allotjament allotjament : allotjaments) {
        if (allotjament.getEstadaMinimaBaixa() < minEstada) {
            minEstada = allotjament.getEstadaMinimaBaixa();
            estadaMesCurta = allotjament;
        }
    }
    return estadaMesCurta;
}

    private Allotjament buscarAllotjament(String id){
        for (Allotjament a : allotjaments){
            if (a.getId().equals(id)) {
                return a;
            }
        }
        return null; //Retorna null si no troba l'allotjament
    }
    private Client buscarClient(String dni){
        return null;
    }
    public static InAllotjament.Temp getTemporada(LocalDate data) {
        int dia = data.getDayOfYear();
        if (dia >= 80 && dia <= 263) { // 21 de març a 20 de setembre
            return InAllotjament.Temp.ALTA;
        } else {
            return InAllotjament.Temp.BAIXA;
        }
    }
}
