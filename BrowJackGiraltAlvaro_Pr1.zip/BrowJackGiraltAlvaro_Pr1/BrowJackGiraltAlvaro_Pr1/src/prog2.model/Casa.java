package prog2.model;

public abstract class Casa extends Allotjament {
    protected int numHabitacions;
    protected int capacitat;

    public Casa(String nom, String id, int estadaMinBaixa, int estadaMinAlta, int numHabitacions, int capacitat) {
        super(nom, id, estadaMinBaixa, estadaMinAlta);
        this.numHabitacions = numHabitacions;
        this.capacitat = capacitat;
    }

    // Getters
    public int getNumHabitacions() {
        return numHabitacions;
    }

    public int getCapacitat() {
        return capacitat;
    }

    // Setters
    public void setNumHabitacions(int numHabitacions) {
        this.numHabitacions = numHabitacions;
    }

    public void setCapacitat(int capacitat) {
        this.capacitat = capacitat;
    }

    @Override
    public abstract boolean correcteFuncionament();

    @Override
    public String toString() {
        return super.toString() + "{numHabitacions=" + numHabitacions + ", capacitat=" + capacitat + "}";
    }
}
