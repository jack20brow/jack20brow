//Clase que gestiona la información de una reserva
package prog2.model;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import prog2.vista.ExcepcioReserva;

public class Reserva {
    private Client client;
    private Allotjament allotjament;
    private LocalDate dataEntrada;
    private LocalDate dataSortida;

    public Reserva(Client client, Allotjament allotjament, LocalDate dataEntrada, LocalDate dataSortida) throws ExcepcioReserva {
        this.client = client;
        this.allotjament = allotjament;
        this.dataEntrada = dataEntrada;
        this.dataSortida = dataSortida;
    }

    public Client getClient() {
        return client;
    }

    public Allotjament getAllotjament() {
        return allotjament;
    }

    public LocalDate getDataEntrada() {
        return dataEntrada;
    }

    public void setClient(Client client) {
        this.client = client;
    }
    public void setAllotjament(Allotjament allotjament){
        this.allotjament = allotjament;
    }
    public void setDataEntrada(LocalDate dataEntrada){
        this.dataEntrada = dataEntrada;
    }

    public LocalDate getDataSortida() {
        return dataSortida;
    }

    public void setDataSortida(LocalDate dataSortida){
        this.dataSortida = dataSortida;
    }
    public long estada() throws ExcepcioReserva {
        long diesEstada = ChronoUnit.DAYS.between(dataEntrada, dataSortida);
        InAllotjament.Temp temporada = Camping.getTemporada(dataEntrada);
        int estadaMinima;

        if (temporada == InAllotjament.Temp.ALTA) {
            estadaMinima = allotjament.getEstadaMinimaAlta();
        }
        else {
            estadaMinima = allotjament.getEstadaMinimaBaixa();
        }

        if (diesEstada < estadaMinima) {
            throw new ExcepcioReserva("Estada mínima no assolida. Mínim requerit: " +
                    estadaMinima + " dies. Dies sol·licitats: " + diesEstada);
        }
        return diesEstada;
    }
}