//Clase que representa a un cliente del camping
package prog2.model;
import prog2.vista.ExcepcioReserva;
public class Client {
    private String nom;
    private String dni;

    public Client(String nom, String dni) throws ExcepcioReserva{
        this.nom = nom;
        this.setDni(dni); //Utilitzem el setter per a validar el dni
    }

    public String getNom(){
        return nom;
    }
    public void setNom(String nom){
        this.nom = nom;
    }

    public String getDni(){
        return dni;
    }
    public void setDni(String dni) throws ExcepcioReserva{
        if(dni.length()!=9){
            throw new ExcepcioReserva("El dni ha de tenir 9 caràcters");
        }
        this.dni = dni;
    }
    @Override
    public String toString() {
        return "Client: " + nom + ", DNI: " + dni;
    }
}
