//Clase que gestiona la lista de reservas del camping
package prog2.model;
import prog2.vista.ExcepcioReserva;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;

public class LlistaReserves {
    private ArrayList<Reserva> reserves;

    public void afegirReserva(Client client,Allotjament allotjament, LocalDate dataEntrada, LocalDate dataSortida) throws ExcepcioReserva {
        if (!allotjamentDisponible(allotjament, dataEntrada, dataSortida)) {
            throw new ExcepcioReserva("L’allotjament amb identificador " + allotjament.getId() +
                    " no està disponible en la data demanada " + dataEntrada +
                    " pel client " + client.getNom() + " amb DNI: " + client.getDni());
        }
        if (!getEstadaMinima(allotjament, dataEntrada, dataSortida)) {
            throw new ExcepcioReserva("Les dates sol·licitades pel client: " + client.getNom() +
                    " amb DNI: " + client.getDni() + " no compleixen l'estada mínima per l'allotjament amb identificador " +
                    allotjament.getId());
        }
        Reserva novaReserva = new Reserva(client, allotjament, dataEntrada, dataSortida);
        reserves.add(novaReserva);
    }

    public boolean allotjamentDisponible(Allotjament allotjament, LocalDate dataEntrada, LocalDate dataSortida) {
        for (int i = 0; i < reserves.size(); i++) {
            Reserva reserva = reserves.get(i);
            if (reserva.getAllotjament().equals(allotjament)) {
                LocalDate existentEntrada = reserva.getDataEntrada();
                LocalDate existentSortida = reserva.getDataSortida();

                //Comprobar solapament entre les dates
                if (dataEntrada.isBefore(existentSortida) && dataSortida.isAfter(existentEntrada)) {
                    return false;
                }
            }
        }
        return true;
    }

    public boolean getEstadaMinima(Allotjament allotjament, LocalDate dataEntrada, LocalDate dataSortida) {
        //retornarà un booleà per indicar si l’estada sol·licitada compleix que és més llarga o
        //igual que l’estada mínima de l’allotjament en la temporada corresponent a la data
        //d’entrada.
        long diesEstada = ChronoUnit.DAYS.between(dataEntrada, dataSortida);
        InAllotjament.Temp temporada = Camping.getTemporada(dataEntrada);
        int estadaMinima;

        if (temporada == InAllotjament.Temp.ALTA) {
            estadaMinima = allotjament.getEstadaMinimaAlta();
        } else {
            estadaMinima = allotjament.getEstadaMinimaBaixa();
        }

        return diesEstada >= estadaMinima;
    }

    public int getNumReserves() {
        return reserves.size();
    }
}
