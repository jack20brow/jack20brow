//Funciona correctamente si tiene terraza con barbacoa.
package prog2.model;

public class MobilHome extends Casa{
    private boolean terrassaBarbacoa;

    public MobilHome(String nom, String id, int estadaMinBaixa, int esatdaMinAlta, int numHabitacions, int capacitat, boolean terrassaBarbacoa) {
        super(nom,id,estadaMinBaixa,estadaMinAlta,numHabitacions,capacitat);
        this.terrassaBarbacoa = terrassaBarbacoa;

    }

    public boolean getTerrassaBarbacoa() {
        return terrassaBarbacoa;
    }

    public void setTerrassaBarbacoa(boolean terrassaBarbacoa) {
        this.terrassaBarbacoa = terrassaBarbacoa;
    }

    @Override
    public boolean correcteFuncionament() {
        return terrassaBarbacoa;
    }

    @Override
    public String toString() {
        return super.toString() + " MobilHome{terrassaBarbacoa=" + terrassaBarbacoa + "}";
    }
}
