package prog2.model;

public class Parcela extends Allotjament {
    private float mida;
    private boolean connexioElectrica;

    public Parcela(String nom, String id, int estadaMinimaBaixa, int estadaMinimaAlta, float mida, boolean connexioElectrica) {
        super(nom, id, estadaMinimaBaixa, estadaMinimaAlta);
        this.mida = mida;
        this.connexioElectrica = connexioElectrica;
    }

    // Getters per mida i connexioElectrica
    public float getMida() {
        return mida;
    }
    public void setMida(float mida) {
        this.mida = mida;
    }

    public boolean isConnexioElectrica() {
        return connexioElectrica;
    }

    @Override
    public boolean correcteFuncionament() {
        return connexioElectrica;
    }

    @Override
    public String toString() {
        return super.toString() + "{mida=" + mida + ", connexioElectrica=" + connexioElectrica + "}";
    }
    public void setConnexioElectrica(boolean connexioElectrica){
        this.connexioElectrica = connexioElectrica;
    }

    public boolean getConnexioElectrica() {
        return connexioElectrica;
    }
}
